from flask import Blueprint, jsonify, request
from flask_login import login_required, current_user
from datetime import datetime
from app import db
from app.models import DataType, DataPermission

data_bp = Blueprint('data', __name__)

@data_bp.route('/data-types', methods=['GET'])
@login_required
def get_data_types():
    """Get all available data types with user's permission status"""
    try:
        data_types = DataType.query.all()
        result = []
        
        for dt in data_types:
            # Check if user has permission for this data type
            permission = DataPermission.query.filter_by(
                user_id=current_user.id,
                data_type_id=dt.id
            ).first()
            
            data = dt.to_dict()
            data['enabled'] = permission.enabled if permission else False
            data['lastRequest'] = 'Nie'  # Simplified for demo
            
            result.append(data)
        
        return jsonify(result)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@data_bp.route('/data-permissions/<int:data_type_id>', methods=['PUT'])
@login_required
def update_data_permission(data_type_id):
    """Update user's data sharing permission"""
    try:
        data = request.get_json()
        enabled = data.get('enabled', False)
        
        # Find or create permission
        permission = DataPermission.query.filter_by(
            user_id=current_user.id,
            data_type_id=data_type_id
        ).first()
        
        if not permission:
            permission = DataPermission(
                user_id=current_user.id,
                data_type_id=data_type_id,
                enabled=enabled
            )
            db.session.add(permission)
        else:
            permission.enabled = enabled
            if enabled:
                permission.last_accessed = datetime.utcnow()
        
        db.session.commit()
        
        return jsonify({
            'success': True,
            'permission': permission.to_dict()
        })
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500