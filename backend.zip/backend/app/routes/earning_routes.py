from flask import Blueprint, jsonify, request
from flask_login import login_required, current_user
from datetime import datetime, timedelta
from sqlalchemy import func
from app import db
from app.models import Earning, Payout, Activity

earning_bp = Blueprint('earning', __name__)

@earning_bp.route('/earnings', methods=['GET'])
@login_required
def get_earnings():
    """Get user's earnings summary"""
    try:
        # Calculate this month's earnings
        start_of_month = datetime.utcnow().replace(day=1, hour=0, minute=0, second=0, microsecond=0)
        
        this_month = db.session.query(func.sum(Earning.amount)).filter(
            Earning.user_id == current_user.id,
            Earning.earned_at >= start_of_month
        ).scalar() or 0.0
        
        # Calculate total earnings
        total = db.session.query(func.sum(Earning.amount)).filter(
            Earning.user_id == current_user.id
        ).scalar() or 0.0
        
        # Calculate pending payouts
        pending = db.session.query(func.sum(Payout.amount)).filter(
            Payout.user_id == current_user.id,
            Payout.status == 'pending'
        ).scalar() or 0.0
        
        # Available = total - completed payouts - pending payouts
        completed_payouts = db.session.query(func.sum(Payout.amount)).filter(
            Payout.user_id == current_user.id,
            Payout.status == 'completed'
        ).scalar() or 0.0
        
        available = total - completed_payouts - pending
        
        return jsonify({
            'thisMonth': this_month,
            'total': total,
            'available': available,
            'pending': pending
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@earning_bp.route('/payouts', methods=['GET'])
@login_required
def get_payouts():
    """Get user's payout history"""
    try:
        payouts = Payout.query.filter_by(user_id=current_user.id).order_by(Payout.requested_at.desc()).all()
        return jsonify([p.to_dict() for p in payouts])
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@earning_bp.route('/payouts', methods=['POST'])
@login_required
def request_payout():
    """Request a new payout"""
    try:
        data = request.get_json()
        amount = float(data.get('amount', 0))
        method = data.get('method', 'paypal')
        
        if amount < 10:
            return jsonify({'error': 'Minimum payout amount is €10'}), 400
        
        # Check available balance
        earnings_data = get_earnings().get_json()
        available = earnings_data.get('available', 0)
        
        if amount > available:
            return jsonify({'error': 'Insufficient balance'}), 400
        
        # Create payout request
        payout = Payout(
            user_id=current_user.id,
            amount=amount,
            method=method,
            status='pending'
        )
        
        db.session.add(payout)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'payout': payout.to_dict()
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@earning_bp.route('/activities', methods=['GET'])
@login_required
def get_activities():
    """Get user's recent activities"""
    try:
        activities = Activity.query.filter_by(user_id=current_user.id).order_by(Activity.created_at.desc()).limit(20).all()
        return jsonify([a.to_dict() for a in activities])
    except Exception as e:
        return jsonify({'error': str(e)}), 500