from flask import Blueprint, jsonify, request
from flask_login import login_required, current_user
from app import db
from app.models import User

user_bp = Blueprint('user', __name__)

@user_bp.route('/user/me', methods=['GET'])
@login_required
def get_current_user():
    """Get current user's information"""
    return jsonify(current_user.to_dict())

@user_bp.route('/user/profile', methods=['PUT'])
@login_required
def update_profile():
    """Update user profile"""
    try:
        data = request.get_json()
        
        # Update allowed fields
        if 'firstName' in data:
            current_user.first_name = data['firstName']
        if 'lastName' in data:
            current_user.last_name = data['lastName']
        if 'birthDate' in data:
            from datetime import datetime
            current_user.birth_date = datetime.strptime(data['birthDate'], '%Y-%m-%d').date()
        if 'country' in data:
            current_user.country = data['country']
        if 'newsletter' in data:
            current_user.newsletter = data['newsletter']
        
        db.session.commit()
        
        return jsonify({
            'success': True,
            'user': current_user.to_dict()
        })
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500